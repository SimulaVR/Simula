#ifndef GODOT_HASKELL_UTIL_H__
#define GODOT_HASKELL_UTIL_H__

#include <gdnative/gdnative.h>

#endif /* GODOT_HASKELL_UTIL_H__ */
