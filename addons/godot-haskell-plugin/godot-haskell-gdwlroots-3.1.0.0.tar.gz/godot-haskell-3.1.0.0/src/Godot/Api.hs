module Godot.Api (module M) where

import Godot.Api.Auto as M
import Godot.Api.VarArgs as M
